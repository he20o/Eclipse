package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.c.board.data.Post;
import com.he20o.util.Cw;

public class ProcMenuList {
	static void run() {
		Cw.wn();
		Cw.edge();
		Cw.wn("리스트");
		Cw.edge2();
		for(Post p : Data.posts) {
			p.infoForList();
			Cw.edge();
		}
		
		
	}

}
