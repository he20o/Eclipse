package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.c.board.data.Post;
import com.he20o.util.Ci;
import com.he20o.util.Cw;

public class ProcMenuRead {
	static void run() {
		Cw.edge();
		Cw.wn();
		Cw.wn("읽기");
		Cw.edge2();
		Cw.wn();
		String cmd = Ci.rl("읽을 글 번호");
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
				Cw.edge();
			}
		}
		
	}

}
