package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.c.board.data.Post;
import com.he20o.util.Ci;
import com.he20o.util.Cw;

public class ProcMenuUpdate {
	static void run() {
		Cw.wn();
		Cw.edge();
		Cw.wn("업데이트");
		Cw.edge2();
		String cmd = Ci.r("수정할 글 번호");
		
		for(Post p : Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				String content=Ci.rl("수정할 글 내용");
				p.content = content;
				Cw.wn("수정되었습니다");
			}
		}
	}

}
