package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.c.board.data.Post;
import com.he20o.util.Ci;
import com.he20o.util.Cw;

public class ProcMenuWrite {
	static void run() {
		Cw.wn();
		Cw.edge();
		Cw.wn("쓰기");
		Cw.edge2();
		String title;
		while(true) {
			title=Ci.rl("글제목");
			if(title.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요.");
			}
		}
		
		String content;
		while(true) {
			content=Ci.rl("글내용");
			if(content.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요.");
			}
		}
		
		String writer;
		while(true) {
			writer=Ci.rl("작성자");
			if(writer.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요");
			}
		}
		
		Post p = new Post(title,content,writer,0);
		Data.posts.add(p);
		Cw.wn();
		Cw.wn("작성되었습니다.");
		Cw.edge();
	}

}
