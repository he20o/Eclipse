package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.util.Ci;
import com.he20o.util.Cw;

public class ProcMenuDel {
	static void run() {
		Cw.wn();
		Cw.edge();
		Cw.wn("삭제");
		Cw.edge2();
		Cw.wn();
		String cmd = Ci.r("삭제할 글 번호");
		
		int tempSearchIndex = 0;
		for(int i=0; i<Data.posts.size();i=i+1) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
				
			}
		}
		
		Data.posts.remove(tempSearchIndex);
		Cw.wn("글 수"+Data.posts.size());
		Cw.edge();
		
	}
	

}
