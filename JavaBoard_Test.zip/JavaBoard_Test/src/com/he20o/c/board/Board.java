package com.he20o.c.board;

import com.he20o.c.board.data.Data;
import com.he20o.c.board.display.Disp;

public class Board {
	public static final String VERSION = "_test3";
	public static final String TITLE = "__게시판__("+VERSION+")feat.he20o";
	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}

}
