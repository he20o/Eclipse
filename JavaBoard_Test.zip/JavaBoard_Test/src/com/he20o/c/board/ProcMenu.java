package com.he20o.c.board;

import com.he20o.c.board.display.Disp;
import com.he20o.util.Ci;
import com.he20o.util.Cw;

public class ProcMenu {
	static void run() {
		Disp.menuMain();
		loop:
			while(true) {
				Cw.wn();
				String cmd = Ci.r("해당 번호를 입력하세요.");
				switch(cmd) {
				case"1":
					ProcMenuList.run();
					break;
				case"2":
					ProcMenuRead.run();
					break;
				case"3":
					ProcMenuWrite.run();
					break;
				case"4":
					ProcMenuDel.run();
					break;
				case"5":
					ProcMenuUpdate.run();
					break;
				case"e":
					Cw.edge();
					System.out.println("프로그램 종료");
					break loop;
					
					default:
						Cw.wn("위의 번호만 입력가능");
						break;
				}
			}
	}

}
