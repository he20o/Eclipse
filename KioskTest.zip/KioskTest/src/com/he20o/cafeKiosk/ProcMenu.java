package com.he20o.cafeKiosk;

public class ProcMenu {
	public void run() {
		yy: while (true) {
			// 메뉴출력



			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				System.out.println("아이스아메리카노");

				Kiosk.basket.add(Kiosk.p1);

				break;

			case "2":
				System.out.println("핫 아메리카노");
				Kiosk.basket.add(Kiosk.p2);
				break;

			case "3":
				System.out.println("오렌지쥬스");
				Kiosk.basket.add(Kiosk.p3);
				break;

			case "x":
				System.out.println("이전 화면으로 이동");
				break yy;
			}

		}
	}

	public void run2() {
		zz: while (true) {
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				System.out.println("마카롱");
				Kiosk.basket.add(Kiosk.p4);
				break;
			case "2":
				System.out.println("스콘");
				Kiosk.basket.add(Kiosk.p5);
				break;
			case "3":
				System.out.println("붕어빵");
				Kiosk.basket.add(Kiosk.p6);
				break;
			case "x":
				System.out.println("이전 화면으로 이동");
				break zz;

			}
		}
	}

	public void run3() {
		vv: while (true) {
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				System.out.println("초코맛아이스크림");
				Kiosk.basket.add(Kiosk.p7);
				break;
			case "2":
				System.out.println("딸기맛아이스크림");
				Kiosk.basket.add(Kiosk.p8);
				break;
			case "3":
				System.out.println("체리맛아이스크림");
				Kiosk.basket.add(Kiosk.p9);
				break;
			case "x":
				System.out.println("이전 화면으로 이동");
				break vv;

			}
		}

	}
}

