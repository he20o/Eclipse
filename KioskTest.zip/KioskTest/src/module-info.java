/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module KioskTest {
}