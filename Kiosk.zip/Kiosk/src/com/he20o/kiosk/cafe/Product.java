package com.he20o.kiosk.cafe;

public class Product {
	//변수들
	String name;
	int price;
	
	//오버로딩 : 함수이름이 같지만 매개변수의 갯수나 형만 달리해서 중복 추가하는 것.
	
	
	//생성자 함수 - 그 중에 매개변수 2개짜리
	Product(String name, int price){
		this.name =name;
		this.price =price;
	}
	Product(int price,String name){
		this.name =name;
		this.price =price;
	}
	
	Product(String name){
		this.name = name;
		this.price =1000;
	}
	Product(){
		
	}
	
	//info - 멤버함수
	public void info() {
		System.out.println(name+"가격:"+price+"원");
	}
		
}
