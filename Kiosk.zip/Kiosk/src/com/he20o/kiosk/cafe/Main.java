package com.he20o.kiosk.cafe;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("===================================");
		System.out.println("=============**CAFE**==============");
		System.out.println("===================================");
//		cf) 자동임포트. ctrl+shift+o

		Product p1 = new Product("아아", 1500);
//		p1.name = "아아";
//		p1.price = 1500;
		Product p2 = new Product("뜨아", 1500);
//		p2.name = "뜨아";
//		p2.price = "1500";
		Product p3 = new Product("마카롱", 2500);
//		p3.name = "마카롱";
//		p3.price = "2500";

		Scanner sc = new Scanner(System.in);
		String cmd;
		loop_a: while (true) {
			System.out.print("명령:[1.음료/2.디저트/x.종료]");
			cmd = sc.next();
			switch (cmd) {
			case "1":
				System.out.println("===================================");
				System.out.println("============**음료LIST**============");
				System.out.println("===================================");
				p1.info();
				p2.info();
				System.out.println("1번 음료");
				loop_b: while (true) {
					System.out.print("명령:[1.커피/2.디카페인/x.논커피]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("1번 커피");
						loop_c: while (true) {
							System.out.println("명령:[1.아아/2.뜨아/x.이전메뉴]");
							cmd = sc.next();
							switch (cmd) {
							case "1":
								System.out.print("아아 1개 선택되었습니다.");
								break;
							case "2":
								System.out.print("뜨아 1개 선택되었습니다.");
								break;
							case "x":
								System.out.print("[이전메뉴로 돌아가기]");
								break loop_c;

							}
						}
						break;
					case "2":
						System.out.println("2번 디카페인");
						loop_d: while (true) {
							System.out.println("명령:[1.디카페인아아/2.디카페인뜨아/x.이전메뉴]");
							cmd = sc.next();
							switch (cmd) {
							case "1":
								System.out.println("디카페인아아 1개 선택되었습니다.");
								break;
							case "2":
								System.out.println("디카페인뜨아 1개 선택되었습니다.");
								break;
							case "x":
								System.out.println("[이전메뉴로 돌아가기]");
								break loop_d;
							}
						}
						break;

					case "x":
						System.out.println("3번 논커피");
						loop_e: while (true) {
							System.out.println("명령:[1.에이드/2.티/x.이전메뉴]");
							cmd = sc.next();
							switch (cmd) {
							case "1":
								System.out.println("에이드 1개 선택되었습니다.");
								break;
							case "2":
								System.out.println("티 1개 선택되었습니다.");
								break;
							case "x":
								System.out.println("[이전메뉴로 돌아가기]");
								break loop_e;
							}
						}
						break loop_b;

					}
				}
				break;
			case "2":
				System.out.println("===================================");
				System.out.println("===========**디저트LIST**============");
				System.out.println("===================================");
				p3.info();
				System.out.println("2번 디저트");
				loop_f: while (true) {
					System.out.println("[1.마카롱/2.선택안함]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("[1.마카롱]");
						loop_g: while (true) {
							System.out.println("[1.초코/2.딸기/3.랜덤/x.이전메뉴]");
							cmd = sc.next();
							switch (cmd) {
							case "1":
								System.out.println("초코맛 선택되었습니다.");
								break;
							case "2":
								System.out.println("딸기맛 선택되었습니다.");
								break;
							case "3":
								System.out.println("랜덤 선택되었습니다.");
								break;
							case "x":
								System.out.println("[이전메뉴로 돌아가기.]");
								break loop_g;
								case"4":
						System.out.println("2.선택안함");
						break loop_f;
							}
							
								
						}
					
					}
				}
				break ;
			case "x":
				break loop_a;
			}
		}
		System.out.println("프로그램 종료");
	}

}
