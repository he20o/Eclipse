/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module Kiosk {
}