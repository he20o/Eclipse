package com.he20o.cafeKiosk;

import com.he20o.util.Cw;

public class ProcMenuDessert {

	public static void run2() {

		for (Product p : KioskObj.product) {
			Cw.wn(p.name);
		}

		zz: while (true) {
			Cw.wn("1.마카롱/2.스콘/3.붕어빵/x.이전메뉴로");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				Cw.wn(KioskObj.product.get(3).name + "선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(3)));
//	            System.out.println("마카롱");
//	            Product a = new Product("마카롱", 2500);
//	            Kiosk.basket.add(a);
				break;
			case "2":
				Cw.wn(KioskObj.product.get(4).name + "선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(4)));

//	            System.out.println("스콘");
//	            Product b = new Product("스콘", 3000);
//	            Kiosk.basket.add(b);
				break;
			case "3":
				Cw.wn(KioskObj.product.get(5).name + "선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(5)));

//	            System.out.println("붕어빵");
//	            Product c = new Product("붕어빵", 2000);
//	            Kiosk.basket.add(c);
				break;
			case "x":
				Cw.wn("이전 화면으로 이동");
				break zz;

			}
		}
	}

	public static void run3() {

		for (Product p : KioskObj.product) {
			Cw.wn(p.name);
		}
		vv: while (true) {
			Cw.wn("1.초코맛아이스크림/2.딸기맛아이스크림/3.체리맛아이스크림/x.이전메뉴로");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				Cw.wn(KioskObj.product.get(6).name + "선택됨");
//	            System.out.println("초코맛아이스크림");
//	            Product d = new Product("초코맛아이스크림", 3000);
				KioskObj.basket.add(new Order(KioskObj.product.get(6)));
				break;
			case "2":
				Cw.wn(KioskObj.product.get(7).name + "선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(7)));
				break;
			case "3":
				Cw.wn(KioskObj.product.get(8).name + "선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(8)));
				break;
			case "x":
				Cw.wn("이전 화면으로 이동");
				break vv;

			}
		}

	}

}
