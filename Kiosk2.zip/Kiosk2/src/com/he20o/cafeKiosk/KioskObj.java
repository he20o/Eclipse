package com.he20o.cafeKiosk;

import java.util.ArrayList;
import java.util.Scanner;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>();
	public static ArrayList<Product> product = new ArrayList<>();

	public static Scanner sc = new Scanner(System.in);

	public static String cmd;

	public static void productLoad() {
		product.add(new Product("아이스아메리카노", 3500));
		product.add(new Product("핫 아메리카노", 3000));
		product.add(new Product("오렌지쥬스", 5000));
	}

	public static void productLoad2() {
		product.add(new Product("마카롱", 2500));
		product.add(new Product("스콘", 3000));
		product.add(new Product("붕어빵", 2000));
	}

	public static void productLoad3() {
		product.add(new Product("초코아이스크림", 3000));
		product.add(new Product("딸기아이스크림", 3000));
		product.add(new Product("체리아이스크림", 3000));
	}

}
