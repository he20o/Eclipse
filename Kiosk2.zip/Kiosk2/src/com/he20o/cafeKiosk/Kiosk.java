package com.he20o.cafeKiosk;

import java.util.ArrayList;
import java.util.Scanner;

import com.he20o.util.Cw;

public class Kiosk {

	void run() {
		System.out.println("");
		KioskObj.productLoad();
		Display.title();
		System.out.println("");
		
		xx: while (true) {
			
			Cw.wn("주문하기[1.음료선택/2.디저트선택/3.아이스크림선택/e.주문완료]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			
			case "1":
				ProcMenuDrink.run();
				break;

			case "2":
				ProcMenuDessert.run2();

				break;

			case "3":
				ProcMenuDessert.run3();
				break;

			case "e":
				System.out.println("");
				Cw.wn("🙌잠시만 기다려주세요🙌");
				System.out.println("");

				break xx;

			}

			Cw.wn("장바구니에 담긴 상품 갯수:" + KioskObj.basket.size());

			int sum = 0;
			for (Order o : KioskObj.basket) {
				sum = sum + o.selectedProduct.price;

			}

			Cw.wn("총 주문금액은 " + sum + "원 입니다.");

			Cw.wn("===================="); //// 산거 리스팅 ////
			for (Order o : KioskObj.basket) {
				Cw.wn(o.selectedProduct.name);
			}
			Cw.wn("====================");
			Cw.wn("프로그램종료");
			break xx;
		}
	}
}
