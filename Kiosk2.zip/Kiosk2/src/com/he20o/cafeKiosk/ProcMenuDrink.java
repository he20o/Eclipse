package com.he20o.cafeKiosk;

import com.he20o.util.Cw;

public class ProcMenuDrink {

	public static void run() {
		for(Product p:KioskObj.product) {// 메뉴출력
			Cw.wn(p.name+""+p.price+"원");
		}
		
		
		yy: while (true) {
			
			Cw.wn("1.커피/2.티/x.이전메뉴로");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				ProcMenuOptionHotCold.run();
//				System.out.println("아이스아메리카노");
//
//				Product x = new Product("아이스아메리카노", 3500);
//				Kiosk.basket.add(x);

				break;

			case "2":
				Cw.wn(KioskObj.product.get(1).name+"선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(1)));
//				System.out.println("핫 아메리카노");
				break;

			case "3":
				Cw.wn(KioskObj.product.get(2).name+"선택됨");
				KioskObj.basket.add(new Order(KioskObj.product.get(2)));
//				System.out.println("오렌지쥬스");
				break;

			case "x":
				Cw.wn("이전 화면으로 이동");
				break yy;
			}

		}
	}

}